# AI-Based Autonomous Navigation System

Simulation-based autonomous navigation using A* algorithm and obstacle avoidance.

## Run
pip install -r requirements.txt
python main.py
