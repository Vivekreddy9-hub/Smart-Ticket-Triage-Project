import numpy as np
import random

class Environment:
    def __init__(self, size=20):
        self.size = size
        self.grid = np.zeros((size, size))
        self.add_obstacles()

    def add_obstacles(self):
        for _ in range(int(self.size * 2)):
            x = random.randint(0, self.size-1)
            y = random.randint(0, self.size-1)
            self.grid[x][y] = 1
