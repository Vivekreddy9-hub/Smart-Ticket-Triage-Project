import pygame

CELL_SIZE = 25

def draw(grid, agent_pos, path):
    pygame.init()
    size = grid.shape[0]
    screen = pygame.display.set_mode((size*CELL_SIZE, size*CELL_SIZE))

    running = True
    clock = pygame.time.Clock()

    while running:
        screen.fill((255,255,255))

        for x in range(size):
            for y in range(size):
                rect = pygame.Rect(y*CELL_SIZE, x*CELL_SIZE, CELL_SIZE, CELL_SIZE)

                if grid[x][y] == 1:
                    pygame.draw.rect(screen, (0,0,0), rect)
                elif (x,y) in path:
                    pygame.draw.rect(screen, (0,255,0), rect)

                pygame.draw.rect(screen, (200,200,200), rect, 1)

        ax, ay = agent_pos
        pygame.draw.rect(screen, (255,0,0),
                         (ay*CELL_SIZE, ax*CELL_SIZE, CELL_SIZE, CELL_SIZE))

        pygame.display.flip()
        clock.tick(5)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

    pygame.quit()
