from src.environment import Environment
from src.planner import astar
from src.agent import Agent
from src.visualization import draw
import time

def run():
    env = Environment(20)
    start = (0,0)
    goal = (19,19)

    path = astar(env.grid, start, goal)

    agent = Agent(start)

    for step in path:
        agent.move(step)
        draw(env.grid, agent.position, path)
        time.sleep(0.2)
