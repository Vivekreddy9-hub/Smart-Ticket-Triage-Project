from simulation.run_simulation import run

if __name__ == "__main__":
    run()
